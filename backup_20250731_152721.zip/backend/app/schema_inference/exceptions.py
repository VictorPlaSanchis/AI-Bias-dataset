class InferenceError(Exception):
    """Error al inferir el tipo de columna."""
    pass