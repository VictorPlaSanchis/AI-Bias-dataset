# Configuraciones generales del backend
APP_NAME = "AI Bias Detector"
