# Schemas de entrada/salida con Pydantic
