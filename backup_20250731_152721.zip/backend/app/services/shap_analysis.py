# Cálculo de SHAP y visualizaciones
