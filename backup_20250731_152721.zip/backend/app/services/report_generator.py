# Generación de reportes HTML y PDF
