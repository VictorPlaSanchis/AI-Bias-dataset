# Lógica de limpieza y detección de tipos
