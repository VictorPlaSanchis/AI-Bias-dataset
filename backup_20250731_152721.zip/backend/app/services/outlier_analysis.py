# Detección de outliers (DBSCAN, Isolation Forest)
