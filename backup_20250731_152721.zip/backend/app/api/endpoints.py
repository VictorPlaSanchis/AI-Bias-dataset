from fastapi import APIRouter, UploadFile, File, HTTPException
import pandas as pd

from app.schema_inference.infer import ColumnTypeInferer

router = APIRouter()

@router.post("/analyze")
async def analyze_dataset(file: UploadFile = File(...)):
    df = pd.read_csv(file.file)
    preview = df.head(3).to_dict(orient="records")
    columns = df.columns.tolist()
    return {"columns": columns, "preview": preview}

@router.post("/schema/infer")
async def infer_schema(file: UploadFile = File(...)):
    """
    Recibe un CSV subido y devuelve un dict {columna: tipo} según schema_inference.
    """
    try:
        df = pd.read_csv(file.file)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error leyendo CSV: {e}")

    inferer = ColumnTypeInferer()
    tipos = {
        col: inferer.infer(df[col]).value
        for col in df.columns
    }
    return {"schema": tipos}

@router.post("/correlation")
async def correlation_analysis(
    file: UploadFile = File(...),
    target: str | None = None
) -> dict:
    """
    Devuelve:
      - numeric_corr: matriz Pearson de todas las numéricas.
      - pearson_target: correlaciones vs. target (si se proporciona).
      - categorical_corr: matriz Cramér’s V de categóricas.
    """
    import pandas as pd
    from app.services.correlation_service import (
        compute_numeric_correlation,
        compute_pearson_with_target,
        compute_categorical_correlation,
    )

    try:
        df = pd.read_csv(file.file)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"CSV inválido: {e}")

    resp: dict = {}
    # Pearson general
    num_corr = compute_numeric_correlation(df)
    resp["numeric_corr"] = num_corr.round(3).to_dict()

    # Pearson vs. target (opcional)
    if target:
        try:
            pt = compute_pearson_with_target(df, target)
            resp["pearson_target"] = pt.round(3).to_dict(orient="index")
        except KeyError as e:
            raise HTTPException(status_code=400, detail=str(e))

    # Categóricas
    cat_corr = compute_categorical_correlation(df)
    resp["categorical_corr"] = cat_corr.round(3).to_dict()

    return resp