# Funciones auxiliares para gestión de archivos
