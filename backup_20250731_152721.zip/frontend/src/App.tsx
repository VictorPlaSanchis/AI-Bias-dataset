function App() {
  return <h1>AI Bias Detector funcionando</h1>
}
export default App
