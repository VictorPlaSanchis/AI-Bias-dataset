// Dashboard con resultados del análisis
